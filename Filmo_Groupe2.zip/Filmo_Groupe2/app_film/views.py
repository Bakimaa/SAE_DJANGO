from django.shortcuts import render
from . forms import ActeurForm
from . import models
from django.http import HttpResponseRedirect
from .forms import PersonnesForm
from django.shortcuts import get_object_or_404
from .forms import CommentaireForm
from django.shortcuts import redirect
from .forms import FilmForm
from .forms import Cat_filmForm
# Create your views here.

def index(request):
    return render(request, 'app_film/index.html')



#CRUD ACTEUR
def ajout_acteur(request):
    aacteur = ActeurForm()
    return render(request, 'app_film/ajout_acteur.html', {'aacteur': aacteur})

def affiche_acteur(request,id):
    act = models.Acteur.objects.get(pk=id)
    return render(request, 'app_film/affiche_acteur.html', {'act': act})

def traitement_acteur(request):
    aacteur = ActeurForm(request.POST, request.FILES)
    if aacteur.is_valid():
        act = aacteur.save()
        return render(request, 'app_film/affiche_acteur.html', {'act': act})
    else:
        return render(request, 'app_film/ajout_acteur.html', {'aacteur': aacteur})

def all_acteur(request):
    liste = models.Acteur.objects.all()
    return render(request, 'app_film/all_acteur.html', {'liste': liste})

def delete_acteur(request,id):
    act = get_object_or_404(models.Acteur, pk=id)
    act.delete()
    return HttpResponseRedirect('/app_film/all_acteur/')

def update_acteur(request, id):
    acteur = models.Acteur.objects.get(pk=id)

    if request.method == "POST":
        form = ActeurForm(request.POST, request.FILES, instance=acteur)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/app_film/all_acteur/')
    else:
        form = ActeurForm(instance=acteur)

    return render(request, 'app_film/update_acteur.html', {'aacteur': form, 'id': id})








#CRUD PERSONNE

def ajout_Personnes(request):
    ppersonne = PersonnesForm()
    return render(request, "app_film/ajout_personne.html", {"ppersonne":ppersonne})

def affiche_Personnes(request,id):
    pform = models.Personnes.objects.get(pk=id)
    return render(request, "app_film/affiche_personne.html", {"pform": pform})

def traitement_Personnes(request):
    ppersonne = PersonnesForm(request.POST)
    if ppersonne.is_valid():
        personne = ppersonne.save()
        # redirection directe vers le commentaire
        return redirect('ajout_commentaire', id=personne.id)
    else:
        return render(request, "app_film/ajout_personne.html", {"ppersonne": ppersonne})

def all_personne(request):
    liste = models.Personnes.objects.all()
    return render(request, 'app_film/all_personne.html', {'liste': liste})

def delete_personne(request,id):
    ppersonne = models.Personnes.objects.get(pk=id)
    ppersonne.delete()
    return HttpResponseRedirect('/app_film/all_personne/')

def update_personne(request,id):
    personne = models.Personnes.objects.get(pk=id)
    if request.method == "POST":
        form = PersonnesForm(request.POST, instance=personne)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/app_film/all_personne/')
    else:
        form = PersonnesForm(instance=personne)

    return render(request, 'app_film/update_personne.html', {'personne': form, 'id': id})








#CRUD COMMENTAIRE

def ajout_commentaire(request, id):
    personne = models.Personnes.objects.get(pk=id)

    if request.method == "POST":
        ccommentaire = CommentaireForm(request.POST)
        if ccommentaire.is_valid():
            commentaire = ccommentaire.save(commit=False)
            commentaire.personne = personne  # on lie automatiquement
            commentaire.save()
            return redirect('all_commentaire')  # ou une page de confirmation
    else:
        ccommentaire = CommentaireForm()

    return render(request, "app_film/ajout_commentaire.html", {
        "ccommentaire": ccommentaire,
        "personne": personne
    })

def affiche_commentaire(request, id):
    cform = models.Commentaire.objects.get(pk=id)
    return render(request, "app_film/affiche_commentaire.html", {"cform": cform})

def traitement_commentaire(request):
    ccommentaire= CommentaireForm(request.POST)
    if ccommentaire.is_valid():
        cform = ccommentaire.save()
        return render(request, "app_film/affiche_commentaire.html", {"cform": cform})
    else:
        return render(request, "app_film/ajout_commentaire.html", {"ccommentaire": ccommentaire})

def all_commentaire(request):
    films = models.Film.objects.all().prefetch_related('commentaire_set')
    return render(request, 'app_film/all_commentaire.html', {'films': films})

def delete_commentaire(request, id):
    cform = models.Commentaire.objects.get(pk=id)
    cform.delete()
    return HttpResponseRedirect('/app_film/all_commentaire/')

def update_commentaire(request, id):
    cform = models.Commentaire.objects.get(pk=id)
    if request.method == "POST":
        form = CommentaireForm(request.POST, instance=cform)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/app_film/all_commentaire/')
    else:
        form = CommentaireForm(instance=cform)

    return render(request, 'app_film/update_commentaire.html', {'commentaire': form, 'id': id})







def ajout_film(request):
    ffilm = FilmForm
    return render(request, 'app_film/ajout_film.html', {'ffilm': ffilm})

def traitement_film(request):
    ffilm = FilmForm(request.POST)
    if ffilm.is_valid():
        Film = ffilm.save()
        return render(request, 'app_film/affiche_film.html', {'Film': Film})
    else:
        return render(request, 'app_film/ajout_film.html', {'ffilm': ffilm})

from django.db.models import Avg, Max, Min

def all_film(request):
    categories = models.Cat_film.objects.all()
    categories_data = []

    for cat in categories:
        films = models.Film.objects.filter(categorie=cat)
        films_data = []

        for film in films:
            # Moyenne des notes par type de personne
            moyennes = (
                models.Commentaire.objects.filter(film=film)
                .values('personne__type')
                .annotate(moy=Avg('note'))
            )

            # Meilleur et pire commentaire
            meilleur = (
                models.Commentaire.objects.filter(film=film).order_by('-note').first()
            )
            pire = (
                models.Commentaire.objects.filter(film=film).order_by('note').first()
            )

            films_data.append({
                'film': film,
                'moyennes': moyennes,
                'meilleur': meilleur,
                'pire': pire
            })

        categories_data.append({
            'categorie': cat,
            'films': films_data
        })

    return render(request, 'app_film/all_film.html', {'categories_data': categories_data})



def affiche_film(request,id):
    Film = models.Film.objects.get(pk=id)
    return render(request, 'app_film/affiche_film.html', {'Film': Film})

def delete_film(request,id):
    film = models.Film.objects.get(pk=id)
    film.delete()
    return HttpResponseRedirect('/app_film/all_film/')

def update_film(request,id):
    ffilm = FilmForm(request.POST)
    if ffilm.is_valid():
        Film = ffilm.save(commit=False)
        Film.id = id;
        Film.save()
        return HttpResponseRedirect('/app_film/all_film/')
    else:
        return render(request, 'app_film/update_film.html', {'film': ffilm, "id": id})







def ajout_categorie(request):
    ccat = Cat_filmForm
    return render(request, 'app_film/ajout_categorie.html', {'ccat': ccat})

def traitement_categorie(request):
    ccat = Cat_filmForm(request.POST)
    if ccat.is_valid():
        Cat = ccat.save()
        return render(request, 'app_film/affiche_categorie.html', {'Cat': Cat})
    else:
        return render(request, 'app_film/ajout_categorie.html', {'ccat': ccat})

def all_categorie(request):
    liste = models.Cat_film.objects.all()
    return render(request, 'app_film/all_categorie.html', {'liste': liste})

def affiche_categorie(request,id):
    Cat = models.Cat_film.objects.get(pk=id)
    return render(request, 'app_film/affiche_categorie.html', {'Cat': Cat})

def delete_categorie(request,id):
    cat = models.Cat_film.objects.get(pk=id)
    cat.delete()
    return HttpResponseRedirect('/app_film/all_categorie/')

def update_categorie(request,id):
    ccat = Cat_filmForm(request.POST)
    if ccat.is_valid():
        Cat = ccat.save(commit=False)
        Cat.id = id;
        Cat.save()
        return HttpResponseRedirect('/app_film/all_categorie/')
    else:
        return render(request, 'app_film/update_categorie.html', {'ccat': ccat, "id": id})