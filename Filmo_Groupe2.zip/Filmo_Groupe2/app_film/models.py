
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator



# Create your models here.

class Acteur(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    age = models.IntegerField(blank=False)
    photo = models.ImageField(upload_to='acteurs/', blank=True, null=True)

    def __str__(self):
        return f"{self.nom} {self.prenom}"

class Personnes(models.Model):
    type = models.CharField(blank=True, max_length=100)
    #identifiant_pers = models.ForeignKey("commentaire", on_delete=models.CASCADE, default=None)
    pseudo = models.CharField(blank=True, max_length=100)
    nom_prenom = models.CharField(blank=True, max_length=100)
    mail = models.CharField(blank=True, max_length=100)
    mot_de_passe = models.CharField(blank=True, max_length=10)

    def __str__(self):
        return self.nom_prenom

    def dico(self):
        return {"Type": self.type, "Pseudo": self.pseudo, "Nom et Prenom": self.nom_prenom, "mail": self.mail, "Mot de passe": self.mot_de_passe}


class Commentaire(models.Model):
    film = models.ForeignKey('Film', on_delete=models.CASCADE, null=True, blank=True)
    personne = models.ForeignKey('Personnes', on_delete=models.CASCADE)
    note = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(10)],
        help_text="Note sur 10"
    )
    commentaire = models.CharField(blank=True, max_length=100)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        chaine = (f"Voici le commentaire publié par {self.personne.nom_prenom} le {self.date}:"
                  f"<br> <strong>{self.commentaire}</strong>"
                  f"<br> {self.note}/10")
        return chaine




class Film(models.Model):
    titre = models.TextField(null = True, blank = True)
    annee_sortie = models.DateField(blank=True, null = True)
    affiche_film = models.FileField(upload_to='acteurs/', blank=True, null=True)
    realisateur = models.TextField(null = True, blank = True)
    categorie = models.ForeignKey("Cat_film", on_delete=models.CASCADE, default=None)
    acteurs = models.ManyToManyField("Acteur", blank=True)

    def __str__(self):
        return self.titre

    def dico(self):
        return {"titre":self.titre, "annee_sortie":self.annee_sortie, "affiche_film":self.affiche_film, "realisateur":self.realisateur, "categorie": self.categorie, "acteur": self.acteur}


class Cat_film(models.Model):
    nom = models.CharField(max_length=100, blank=False)
    descriptif = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.nom

    def dico(self):
        return {"nom": self.nom, "descriptif":self.descriptif}
