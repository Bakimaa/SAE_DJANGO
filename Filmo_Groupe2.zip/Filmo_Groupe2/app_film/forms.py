from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models
from django import forms

class ActeurForm(ModelForm):
    class Meta:
        model = models.Acteur
        fields = '__all__'
        label = {
            'nom': 'Nom',
            'prenom': 'Prenom',
            'age': 'Age',
            'photo': 'Photo',
        }

class PersonnesForm(ModelForm):
    class Meta:
        model = models.Personnes
        fields = ('type', 'pseudo', 'nom_prenom', 'mail', 'mot_de_passe')
        labels = {
            'type': _('Type'),
            'pseudo': _('Pseudo'),
            'nom_prenom': _('Nom et Prénom'),
            'mail': _('Adresse mail'),
            'mot_de_passe': _('Mot de passe')
        }

class CommentaireForm(ModelForm):
    class Meta:
        model = models.Commentaire
        exclude = ['personne']
        fields = '__all__'
        labels = {
            'note': _('Note'),
            'commentaire': _('Commentaire'),
            'date': _('Date de la commentaire'),
            #'film': _('Film'),
            #'personne': _('personne'),
        }


class FilmForm(ModelForm):
    class Meta:
        model = models.Film
        fields = '__all__'
        labels = {
            'titre' : _('Titre'),
            'annee_sortie' : _('Année de sortie') ,
            'affiche_film' : _('Affiche du film'),
            'realisateur' : _('Réalisateur'),
            'categorie' : _('Catégorie'),
            'acteurs' : _('Acteur'),
        }
        widgets = {
        'acteurs': forms.CheckboxSelectMultiple()
        }



class Cat_filmForm(ModelForm):

    class Meta:
        model = models.Cat_film
        fields = ('nom', 'descriptif')
        labels = {
            'nom' : _('nom'),
            'descriptif' : _('descriptif'),
        }
