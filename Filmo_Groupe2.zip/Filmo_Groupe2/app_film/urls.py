from django.urls import path
from . import views

urlpatterns = [
    path('ajout_acteur/', views.ajout_acteur, name='ajout_acteur'),
    path('affiche_acteur/<int:id>/', views.affiche_acteur, name='affiche_acteur'),
    path('traitement_acteur/', views.traitement_acteur, name='traitement_acteur'),
    path('all_acteur/', views.all_acteur, name='all_acteur'),
    path('delete_acteur/<int:id>/', views.delete_acteur, name='delete_acteur'),
    path('update_acteur/<int:id>/', views.update_acteur, name='update_acteur'),


    path('ajout_personne/', views.ajout_Personnes, name='ajout_personne'),
    path('affiche_personne/<int:id>/', views.affiche_Personnes, name='affiche_personne'),
    path('traitement_personne/', views.traitement_Personnes, name='traitement_personne'),
    path('all_personne/', views.all_personne, name='all_personne'),
    path('delete_personne/<int:id>/', views.delete_personne, name='delete_personne'),
    path('update_personne/<int:id>/', views.update_personne, name='update_personne'),

    path('ajout_commentaire/<int:id>/', views.ajout_commentaire, name='ajout_commentaire'),
    path('affiche_commentaire/<int:id>/', views.affiche_commentaire, name='affiche_commentaire'),
    path('traitement_commentaire/<int:id>/', views.traitement_commentaire, name='traitement_commentaire'),
    path('all_commentaire/', views.all_commentaire, name='all_commentaire'),
    path('delete_commentaire/<int:id>/', views.delete_commentaire, name='delete_commentaire'),
    path('update_commentaire/<int:id>/', views.update_commentaire, name='update_commentaire'),

    path('ajout_film/', views.ajout_film, name='ajout_film'),
    path('affiche_film/<int:id>/', views.affiche_film, name='affiche_film'),
    path('traitement_film/', views.traitement_film, name='traitement_film'),
    path('update_film/<int:id>/', views.update_film, name='update_film'),
    path('delete_film/<int:id>/', views.delete_film, name='delete_film'),
    path('all_film/', views.all_film, name='all_film'),
    #pages pour les catégorie de film
    path('ajout_categorie/', views.ajout_categorie, name='ajout_categorie'),
    path('affiche_categorie/<int:id>/', views.affiche_categorie, name="affiche_categorie"),
    path('traitement_categorie/', views.traitement_categorie, name='traitement_categorie'),
    path('update_categorie/<int:id>/', views.update_categorie, name='update_categorie'),
    path('delete_categorie/<int:id>/', views.delete_categorie, name='delete_categorie'),
    path('all_categorie/', views.all_categorie, name='all_categorie'),


    path('index/', views.index, name='index'),
    ]
